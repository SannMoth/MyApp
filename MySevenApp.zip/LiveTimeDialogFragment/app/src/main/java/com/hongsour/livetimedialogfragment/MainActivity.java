package com.hongsour.livetimedialogfragment;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import java.util.Calendar;
public class MainActivity extends AppCompatActivity {

    Button DOBbtn;
    TextView liveTextView;
    Calendar c = Calendar.getInstance();
    int curYear = c.get(Calendar.YEAR);
    int curMonth = c.get(Calendar.MONTH);
    int curDay = c.get(Calendar.DAY_OF_MONTH);
    String liveTime;
    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DOBbtn = (Button) findViewById(R.id.btnDate);
        liveTextView = (TextView) findViewById(R.id.textExit);

        // Set OnClickListener for Date button
        DOBbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDOBBtnClick(v);
            }
        });

        // Set OnClickListener for Time button
        Button timeButton = findViewById(R.id.btnTime);
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onTimeBtnClick(v);
            }
        });

        // Set OnClickListener for Exit button
        Button exitButton = findViewById(R.id.btnExit);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onExitBtnClick(v);
            }
        });
    }
    public void onDOBBtnClick (View v) {
        datePickerDialog = new DatePickerDialog(MainActivity.this, dateSetListener, curYear, curMonth, curDay);
        datePickerDialog.show();
    }
    private DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            calLiveDay(year, month, dayOfMonth);
        }
    };
    public void onTimeBtnClick(View v) { // Method name and parameter added
        final Calendar cldr = Calendar.getInstance(); // Get current time
        int hour = cldr.get(Calendar.HOUR_OF_DAY); // Get current hour
        int minutes = cldr.get(Calendar.MINUTE); // Get current minute

        // Create time picker dialog
        timePickerDialog = new TimePickerDialog(MainActivity.this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
                        liveTextView.setText(selectedHour + ":" + selectedMinute); // Update text view
                    }
                }, hour, minutes, true); // Pass current time and 24-hour format

        timePickerDialog.show(); // Show the dialog
    }

    private void confirmExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(android.R.drawable.ic_dialog_alert) // Set icon
                .setCancelable(false) // Prevent dialog from being canceled by back button
                .setMessage("Are you sure you want to exit?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.this.finish(); // Exit the activity
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss(); // Dismiss the dialog
                    }
                });

        AlertDialog alert = builder.create();
        alert.show(); // Show the dialog
    }

    public void onExitBtnClick (View v){
        confirmExitDialog();
    }
    private void calLiveDay(int year, int month, int day) {
        int yearToDay;
        int monthToDay;
        int dayToDay;
        int liveDay;
        yearToDay = (curYear - year) * 365;

        if (curMonth >= month) {
            monthToDay = (curMonth - month) * 30;
        } else {
            monthToDay = ((curMonth - month + 12) * 30) - 365;
        }
        dayToDay = curDay - day;
        liveDay = yearToDay + monthToDay + dayToDay;
        liveTextView.setText("Up time: " + liveDay + " days.");
    }



}